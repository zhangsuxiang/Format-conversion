% 输入与输出文件路径
xlsxFile   = 'duanceng_with_instability.xlsx';  %输入文件
csvFile    = 'duanceng_with_tendcy.csv';   %格式转换，此处不需要修改
outputFile = 'processed_data.txt';   %输出

%% 1. 如果不存在CSV，则从Excel生成
if ~isfile(csvFile)
    try
        % 读取Excel所有内容，无表头
        T = readtable(xlsxFile, 'FileType','spreadsheet', 'ReadVariableNames', false);
        % 写出为CSV，不包含变量名
        writetable(T, csvFile, 'FileType','text', 'WriteVariableNames', false, 'Delimiter', ',');
        fprintf('已将 %s 转换为 %s\n', xlsxFile, csvFile);
    catch ME
        error('Excel转CSV失败：%s', ME.message);
    end
else
    fprintf('检测到已存在CSV文件，跳过Excel转换：%s\n', csvFile);
end

%% 2. 按行读取CSV并处理
fid = fopen(csvFile, 'r');
if fid == -1
    error('无法打开CSV文件：%s', csvFile);
end

result = {};
previous_id = '';
lineNum = 0;

while ~feof(fid)
    line = fgetl(fid);
    if ~ischar(line), continue; end  % 跳过空或非字符行
    line = strtrim(line);
    if isempty(line), continue; end    % 跳过空行
    lineNum = lineNum + 1;

    % 拆分逗号分隔字段
    tokens = strsplit(line, ',');
    if numel(tokens) < 4
        warning('第 %d 行字段少于4列，已跳过：%s', lineNum, line);
        continue;
    end

    % 提取ID及第2-4列
    current_id = tokens{1};
    if ~isempty(previous_id) && ~strcmp(current_id, previous_id)
        result{end+1,1} = '>';
    end
    result{end+1,1} = strjoin(tokens(2:4), ',');
    previous_id = current_id;
end
fclose(fid);

%% 3. 写入处理结果到TXT
outfid = fopen(outputFile, 'w');
if outfid == -1
    error('无法创建输出文件：%s', outputFile);
end
for i = 1:numel(result)
    fprintf(outfid, '%s\n', result{i});
end
fclose(outfid);

fprintf('处理完成，共写入 %d 行，结果已保存到：%s\n', numel(result), outputFile);